<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta http-equiv="refresh" content="0; url=http://552.dopa.com.cn/?dm=parked-domain.org&acc=455d5910-312c-4ad4-a979-956606aa2c4b&poprequest=1&ref=http://91yb.ccaeo.com/">
<script type="text/javascript">
function redirect(){
	window.location.href = "http://552.dopa.com.cn/?dm=parked-domain.org&acc=455d5910-312c-4ad4-a979-956606aa2c4b&poprequest=1&ref=http://91yb.ccaeo.com/";	
}
setTimeout('redirect()',1500);
</script>
<title></title>
</head>
<body>
</body>
</html>